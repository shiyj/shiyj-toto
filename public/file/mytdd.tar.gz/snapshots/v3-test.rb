require 'test/unit'
require './v3'

class MytddTests < Test::Unit::TestCase
	def test_sort_text
		 assert_equal([{:name=>'Linux',:num=>50,:is_even=>true},
		               {:name=>'Windows', :num=>20, :is_even=>true}],
		               sort_text("Windows 20\nLinux 50\n"))
	end
	def test_read_in_arr
    assert_equal([["Linux", "22"], ["Windows", "54"], ["MacOS", "26"]],
                 read_in_arr("Linux 22\nWindows 54\nMacOS 26\n"))
  end
  def test_read_in_hash
    assert_equal([{:name=>'Windows',:num=>2,:is_even=>true},
                 {:name=>'Linux',:num=>5,:is_even=>false}],
                 read_in_hash([["Windows", "2"],["Linux", "5"]]))
  end
  def test_sort_arr_hash
    assert_equal([{:name=>'Windows',:num=>27,:is_even=>false},
                 {:name=>'Linux',:num=>5,:is_even=>false}],
                 sort_arr_hash(read_in_hash([["Windows", "27"],["Linux", "5"]])))
    assert_equal([{:name=>'Linux',:num=>77,:is_even=>false},
                 {:name=>'Windows',:num=>52,:is_even=>true}],
                 sort_arr_hash(read_in_hash([["Windows", "52"],["Linux", "77"]])))
  end
end
