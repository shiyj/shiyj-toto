require 'open-uri'

def sort_text text
end
url = 'http://localhost:8080'
page = open(url).read
p sort_text page
