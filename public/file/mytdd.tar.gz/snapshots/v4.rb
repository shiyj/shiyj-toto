require 'open-uri'

def sort_text text
  arr=read_in_arr text
  arr_hash=read_in_hash arr
  result=sort_arr_hash arr_hash
end
def read_in_arr text
end
def read_in_hash arr
end
def sort_arr_hash arr_hash
end
url = 'http://localhost:8080'
page = open(url).read
p sort_text page
