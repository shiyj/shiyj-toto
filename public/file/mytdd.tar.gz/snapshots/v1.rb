require 'open-uri'

url = 'http://localhost:8080'
page = open(url).read
p sort_text page
