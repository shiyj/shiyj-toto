require 'test/unit'
require './v2'

class MytddTests < Test::Unit::TestCase
	def test_sort_text
		 assert_equal([{:name=>'Linux',:num=>50,:is_even=>true},
		               {:name=>'Windows', :num=>20, :is_even=>true}],
		               sort_text("Windows 20\nLinux 50\n"))
	end
end
