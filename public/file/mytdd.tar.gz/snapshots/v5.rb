require 'open-uri'

def sort_text text
  arr=read_in_arr text
  arr_hash=read_in_hash arr
  result=sort_arr_hash arr_hash
end
def read_in_arr text
  arr=text.split("\n").map do |word|
    word.split
  end
end
def read_in_hash arr
  arr_hash = arr.map do |value|
    hash={}
    hash[:name]=value.first
    hash[:num]=value.last.to_i
    hash[:is_even]= hash[:num].even?
    hash
  end
end
def sort_arr_hash arr_hash
  arr_hash.sort_by {|x| -x[:num]}
end
url = 'http://localhost:8080'
page = open(url).read
p sort_text page
